import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import OpenAI from "openai";

// Initialize OpenAI with API key check
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Live Chat AI Assistant endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      // Check if OpenAI is available
      if (!openai) {
        return res.json({ 
          response: "Maaf, layanan AI chat sedang tidak tersedia. Silakan hubungi Ricky Fernando langsung melalui WhatsApp di +62 815-1362-4314 atau email di pucha.anime@gmail.com untuk pertanyaan tentang layanan sound engineering."
        });
      }

      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are Pucha AI, Ricky Fernando's AI assistant. Ricky is a professional sound engineer and soundman who specializes in live concerts, audio mixing, and sound system management. Help users with questions about sound engineering, booking services, or general inquiries about Ricky's work. Be friendly, professional, and knowledgeable about audio engineering. Always respond in Indonesian since that's Ricky's primary language."
          },
          {
            role: "user",
            content: message
          }
        ],
        max_tokens: 150,
        temperature: 0.7
      });

      const aiResponse = response.choices[0]?.message?.content || "Maaf, saya tidak dapat memproses pesan Anda saat ini.";
      
      res.json({ response: aiResponse });
    } catch (error) {
      console.error("AI Chat error:", error);
      res.status(500).json({ error: "Terjadi kesalahan saat memproses pesan Anda. Silakan coba lagi nanti." });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
